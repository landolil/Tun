# PROD-11: Feed Preparation & Shredding
## CSMFAB000000000108 - Aegis-Forge I Planetary Centrifugal Inductive Material Separation
### Series: TCIMS (Thermal Cascade Inductive Material Separator) | Document 11 of 40
**Classification:** Foundation Technology - Seed Material Production
**Prepared by:** Carrington Storm Motors, Safe Pod Engineering Company, Fabrication Division
**Date:** November 2026 | **Revision:** 1.0

---

## 1. Purpose & Design Mandate

The Feed Preparation & Shredding subsystem is the **gateway** of the Aegis-Forge I. Every kilogram of material entering the thermal cascade must first pass through this system: ferrous pre-separation, size reduction to <150 mm, acoustic pre-liberation, and moisture verification. The output of this subsystem directly determines the efficiency, purity, and throughput of all eight downstream thermal stages.

**Design Mandate:**
- Zero structural metals in the shredder chamber — BFRP blades, PEEK CF40 liners, ceramic bearings
- Permanent magnet ferrous separation (1.2T NdFeB belt) removing 40-60% ferrous mass pre-shredder
- Particle size control: Rosin-Rammler distribution targeting <150 mm maximum, optimal liberation
- Moisture gate: Capacitive sensing at >25% triggers 80°C pre-dry before drum entry
- Acoustic pre-chamber: 1-minute LF/ultrasonic mineral liberation at ambient conditions
- Throughput: 500 kg/hr continuous feed rate matched to drum batch cycle
- All-dielectric construction: No copper, no steel, no aluminum in process-contact zones
- Carrington immunity: No conductive paths, no ferromagnetic components

**The Irreducible Constraint:** *The Aegis-Forge I drum is a dielectric citadel — a rotating ZrB2-SiC ceramic pressure vessel at 2200°C. Any metallic contamination entering the drum (steel blade fragments, ferrous wire, copper shreds) becomes a permanent defect in the ceramic matrix, creates GIC coupling paths, or forms intermetallic compounds that poison downstream separation. The shredder must reduce heterogeneous waste to a controlled particle distribution without introducing a single gram of metallic debris.*

This constraint forces every design decision: BFRP composite blades (basalt fiber/Elium®) instead of hardened steel, PEEK CF40 chamber liners instead of manganese steel, ceramic hybrid bearings instead of steel rollers, and a permanent magnet separation belt upstream that removes the bulk ferrous fraction before it ever reaches the shredder.

---

## 2. Feedstock Categories A-D — Input Specification

The Aegis-Forge I accepts four fundamentally distinct feedstock categories. Each category has different pre-processing requirements, thermal behavior, and downstream routing. The feed preparation system must handle all four without cross-contamination.

### 2.1 Category A — Electronics and PCBs

**Composition:**
- Printed circuit boards: FR4 glass-epoxy laminate (SiO2 reinforcement → slag, Cu traces → Stage 6, Sn/Pb solder → Stage 4, Au/Ag/Pd traces → Stage 6)
- Smartphones, tablets, laptops: Al chassis (Stage 5), Li-ion batteries (pre-removed), rare earth magnets (NdFeB → Stage 7 recovery)
- Motors and drives: Cu windings (Stage 6), Fe stators (Stage 7), rare earth rotor magnets (Stage 7)

**Pre-processing requirements:**
- Battery removal (manual or automated vision sort) — Li-ion cells are explosion hazard in shredder
- PCB depopulation optional — whole boards shredded; components liberate in Stage 0 acoustic
- Ferrous pre-separation critical: motor stators, transformer cores removed at 1.2T belt
- Target particle size: <50 mm for PCB fragments (enhances Stage 0 liberation)

**Mass fraction (typical mixed e-waste):** 15-25% of input

### 2.2 Category B — Structural Metals and Alloys

**Composition:**
- Aluminum extrusions, castings: 6061, 2024, A356 die-cast (Stage 5, 660-720°C)
- Copper pipe, wire, busbar: 99.9% Cu (Stage 6, 1085-1200°C)
- Steel and iron scrap: rebar, plate, structural (Stage 7, 1200-1600°C)
- Zinc die-cast: Zamak 3, 5 (Stage 4, 420°C)
- Mixed assemblies: Al/steel riveted, Cu/Al bimetal lugs

**Pre-processing requirements:**
- Ferrous pre-separation removes >90% of steel/iron mass at magnet belt
- Non-ferrous metals pass to shredder — size reduction critical for thermal ramp rate
- Large castings (engine blocks, transmission cases) require primary crushing before shredder
- Target particle size: <100 mm for structural metals (faster induction coupling)

**Mass fraction (typical industrial scrap):** 30-50% of input

### 2.3 Category C — Rock, Ore, and Mineral Concentrates

**Composition:**
- Basalt rock aggregate: SiO2 45-55%, Al2O3 12-17%, FeOx 9-15% (basalt fiber feedstock)
- Zircon sand concentrate: ZrSiO4 → ZrO2 extraction (Stage 8, 1676°C dissociation)
- Rare earth oxide concentrate: Monazite (Ce,La,Nd,Th), bastnäsite (Stage 7/8 RE recovery)
- Ilmenite sand: FeTiO3 → TiO2 extraction (Stage 7 Fe + Stage 8 Ti)
- Borax ore: Na2B4O7 → B2O3 for ZrB2 synthesis (Stage 8)

**Pre-processing requirements:**
- No ferrous pre-separation needed (minerals are non-magnetic except ilmenite)
- Primary crushing to <150 mm typically done at mine/quarry
- Acoustic pre-chamber (Stage 0) critical: liberates mineral grains from rock matrix
- Moisture check essential: ore concentrates often >10% free moisture
- Target particle size: <75 mm for mineral concentrates (optimizes Stage 0 liberation)

**Mass fraction (mineral feedstock runs):** 20-40% of input

### 2.4 Category D — Phoenix Protocol Returns (Aegis Product EOL)

**Composition:**
- Retired Aegis-C panels: ZrB2-SiC ceramic + aerogel + YInMn Blue glaze (Stage 8 mineral recovery)
- End-of-life BFRP structural components: Basalt/Elium® composite (pyrolysis → Stage 3 char + Stage 1 vapor)
- Spent MR fluid: Iron carbonyl suspension in carrier oil (Stage 7 Fe recovery, Stage 3 organics)
- Old KNbO3-BaTiO3 piezo elements: K, Nb, Ba, Ti recovery (Stage 8 mineral)

**Pre-processing requirements:**
- Known composition — no sorting surprises, but material is already ceramic/composite
- Shredder must handle ZrB2-SiC (hardness ~25 GPa) — BFRP blade wear accelerated
- BFRP components pyrolyze cleanly in Stage 3 (Elium® depolymerizes at 350°C)
- No ferrous pre-separation needed (Aegis products are zero-metal by design)
- Target particle size: <50 mm for ceramic panels (enhances Stage 8 dissociation)

**Mass fraction (closed-loop operation):** 5-15% of input

---

### 2.5 Feedstock Summary Table

| Parameter | Category A (Electronics) | Category B (Structural Metals) | Category C (Minerals) | Category D (Phoenix Returns) |
|-----------|-------------------------|--------------------------------|----------------------|------------------------------|
| **Typical Mass %** | 15-25% | 30-50% | 20-40% | 5-15% |
| **Ferrous Content** | 10-20% (motors, frames) | 40-70% (steel/iron) | 0-15% (ilmenite) | 0% (by design) |
| **Target Particle Size** | <50 mm | <100 mm | <75 mm | <50 mm |
| **Moisture Typical** | <5% | <2% | 5-15% | <1% |
| **Pre-dry Trigger** | >25% | >25% | >25% | >25% |
| **Stage 0 Liberation** | Critical (PCB delam) | Moderate | Critical (grain boundary) | Moderate |
| **Hazard Items** | Li-ion batteries | Large castings, pressure vessels | None | None |
| **Downstream Stages** | 3, 4, 5, 6, 7 | 4, 5, 6, 7 | 0, 1, 8 | 3, 8 |

---

## 3. Pre-processing Flow — From Infeed to Drum Gate

The feed preparation system operates as a continuous-flow pre-processor ahead of the batch-mode thermal cascade. Material moves through four sequential stations, each designed to remove a specific contaminant class or condition the feed for optimal cascade performance.

### 3.1 Flow Architecture

```
FEED PREPARATION FLOW DIAGRAM

[RAW INFEED HOPPER] (2 m³ live capacity, vibratory feeder)
        |
        v
[STATION 1: FERROUS SEPARATION BELT]
|  NdFeB permanent magnet drum, 1.2T surface field
|  Belt speed: 0.5 m/s, width: 800 mm
|  Ferrous fraction diverted → [FERROUS SLUG COLLECTION] (direct to Stage 7 feed)
|  Non-ferrous fraction → 
        |
        v
[STATION 2: BFRP-BLADE SHREDDER]
|  800 mm rotor, 32 BFRP blades, PEEK CF40 liners
|  Output: <150 mm, Rosin-Rammler n=1.2-1.5
|  Dust extraction: BFRP cyclone + HEPA (PM2.5 capture)
        |
        v
[STATION 3: ACOUSTIC PRE-CHAMBER (Stage 0 Pre-liberation)]
|  KNbO3-BaTiO3 transducer array: LF 20-200 Hz + US 40 kHz
|  Residence: 60 sec ambient, N2 atmosphere
|  Liberates mineral grains, delaminates PCBs, fractures organics
        |
        v
[STATION 4: MOISTURE GATE & PRE-DRY]
|  Capacitive moisture sensor (RF dielectric measurement)
|  Threshold: >25% moisture → divert to 80°C pre-dry chamber (15 min)
|  <25% moisture → direct to drum feed gate
        |
        v
[DRUM FEED GATE] → [ZrB2-SiC DRUM ENTRY PORT] (PEEK CF40 seal, ZrO2 ceramic)
```

### 3.2 Station 1: Ferrous Pre-separation — The Critical First Cut

**Why first?** Ferrous metal (steel, iron) is the highest-mass contaminant in Categories A and B. At 40-70% of structural scrap mass, ferrous material would:
- Overload the shredder (steel work-hardens, destroys BFRP blades)
- Dilute the thermal cascade (Fe melts at 1538°C — Stage 7, but enters at Stage 1)
- Contaminate non-ferrous slugs (Fe particles in Al/Cu slugs ruin purity)
- Create GIC coupling paths if steel fragments reach drum

**Solution: Permanent magnet belt separator — no electromagnets, no power, no copper windings.**

| Parameter | Specification | Rationale |
|-----------|---------------|-----------|
| Magnet material | NdFeB N52 (sintered, Ni-Cu-Ni coated) | 1.2T surface field, max energy product |
| Belt width | 800 mm | Matches shredder infeed width |
| Belt speed | 0.5 m/s (adjustable 0.3-0.8 m/s) | Optimal dwell for 50-150 mm particles |
| Drum diameter | 300 mm | High gradient at surface |
| Pole configuration | 16-pole alternating N-S | Maximum field gradient for capture |
| Ferrous capture efficiency | 95%+ for particles >10 mm | Verified by mass balance |
| Non-ferrous carryover | <2% mass | Acceptable for downstream separation |
| Maintenance | Zero (permanent magnet) | No coils, no power, no cooling |

**Ferrous output routing:** Captured ferrous fraction bypasses shredder entirely. It travels via BFRP chute directly to the **Stage 7 feed buffer** (ferrous cascade stage, 1200-1600°C). This is a dedicated feed path — ferrous material never enters the shredder, never contaminates the acoustic chamber, and never dilutes the non-ferrous thermal cascade.

### 3.3 Station 2: BFRP-Blade Shredder — Dielectric Size Reduction

**Core principle:** A shredder that shreds everything *except itself*.

The 800 mm diameter rotor carries 32 BFRP (Basalt Fiber Reinforced Polymer, Elium® matrix) blades arranged in a staggered helical pattern. The chamber is lined with 12 mm PEEK CF40 wear plates. The rotor shaft runs on Si3N4 ceramic hybrid bearings. The drive is a KNbO3-BaTiO3 ultrasonic piezoelectric motor (same as drum drive) — zero electromagnetic components in the shredder housing.

| Parameter | Specification |
|-----------|---------------|
| Rotor diameter | 800 mm |
| Rotor length | 600 mm (matches drum working length) |
| Blade count | 32 (8 rows × 4 helical positions) |
| Blade material | BFRP (Basalt/Elium®), 60% FVF, 4 mm thick |
| Blade profile | Hooked leading edge, 15° relief angle |
| Chamber liner | PEEK CF40, 12 mm replaceable segments |
| Bearing type | Si3N4 ceramic hybrid (ceramic balls, PEEK cage) |
| Drive motor | KNbO3-BaTiO3 ultrasonic piezoelectric, 15 kW |
| Rotor speed | 120 RPM (2 Hz) — low speed, high torque |
| Torque | 12,000 Nm peak |
| Throughput | 500 kg/hr (mixed feed) |
| Output size | <150 mm (95% passing), P80 = 75 mm |
| Specific energy | 0.8-1.5 kWh/ton (material dependent) |

**Blade geometry and cutting mechanics:**

The BFRP blades are not sharpened like steel knives — they rely on **impact fracture** and **progressive delamination** of the composite against the feed material. The hooked leading edge initiates cracks in brittle materials (glass, ceramic, PCB laminate) and peels ductile materials (Al, Cu, plastic) through cyclic bending.

```
BLADE CROSS-SECTION (BFRP composite layup):

    [BFRP SKIN: 2mm 0°/90° woven basalt/Elium®]
    |
    |  <-- Neutral axis at mid-thickness
    |
    [BFRP CORE: 4mm unidirectional basalt roving, 0° orientation]
    |
    |  <-- Maximum tensile stress at outer fiber during impact
    |
    [BFRP SKIN: 2mm 0°/90° woven basalt/Elium®]

Total thickness: 8 mm (4 mm structural core + 2×2 mm skins)
FVF (Fiber Volume Fraction): 60%
Interlaminar shear strength: 65 MPa (Elium® matrix)
Mode I fracture toughness: 35 kJ/m²
```

**Why this works:** Basalt fiber has tensile strength of 3,000-4,840 MPa — comparable to S-glass but with 700°C continuous service temperature. The Elium® thermoplastic matrix allows the blade to absorb impact energy through controlled delamination rather than catastrophic fracture. When a blade segment fails, it delaminates progressively; the rotor continues operating with reduced cutting efficiency until scheduled replacement.

### 3.4 Station 3: Acoustic Pre-Chamber — Stage 0 Pre-liberation

**Purpose:** Before thermal processing, apply acoustic energy to liberate mineral grains from rock matrix, delaminate PCB layers, and fracture organic binders — all at ambient temperature.

The acoustic pre-chamber is a BFRP-lined cylinder (800 mm ID × 1000 mm length) with 48 KNbO3-BaTiO3 transducers embedded in the wall: 24 LF (20-200 Hz) for macro-fracture and 24 ultrasonic (40 kHz) for grain-boundary liberation.

| Parameter | Specification |
|-----------|---------------|
| Chamber volume | 0.5 m³ |
| Transducer count | 48 (24 LF + 24 US) |
| LF frequency range | 20-200 Hz (swept sine, resonance tracking) |
| US frequency | 40 kHz (cavitation in interstitial moisture) |
| Acoustic pressure | 140-160 dB SPL (LF), 180 dB SPL (US) |
| Residence time | 60 seconds |
| Atmosphere | Nitrogen (inert, prevents oxidation) |
| Throughput | 500 kg/hr (continuous flow) |

**Liberation mechanisms:**

1. **LF Stress Waves (20-200 Hz):** Wavelength λ = c/f ≈ 1.7-17 m in rock — whole-particle resonance. Induces tensile stress at material interfaces (mineral grain boundaries, PCB laminate layers). Stress wave equation:
   
   $$σ_{acoustic} = ρ c ω u_{max}$$
   
   For basalt (ρ=2800 kg/m³, c=5500 m/s) at 100 Hz, 1 mm displacement: σ ≈ 9.7 MPa — exceeds tensile strength of weathered rock interfaces.

2. **Ultrasonic Cavitation (40 kHz):** In residual moisture films at grain boundaries, 40 kHz creates transient cavitation bubbles. Collapse pressure:
   
   $$P_{collapse} ≈ 0.1 \frac{ρ c^2}{γ} ≈ 500 \text{ MPa}$$
   
   This micro-jetting fractures grain boundaries without bulk heating.

3. **PCB Delamination:** LF resonance matches FR4 panel modes (50-150 Hz). Cyclic bending fatigues the glass-epoxy/copper interface. Copper foil peels from substrate — liberates Cu for Stage 6, fiberglass for Stage 8 slag.

**Output:** Pre-liberated feed with 30-50% reduction in bonded composite particles. Downstream Stage 0 (in-drum acoustic) then completes liberation at temperature.

### 3.5 Station 4: Moisture Gate & Pre-dry

**Why moisture matters:** Water entering the drum at Stage 1 (80-150°C) flashes to steam, consuming 2257 kJ/kg latent heat. At 500 kg/hr feed with 10% moisture = 50 kg/hr water = 31 kW parasitic load on Zone 1-2 inverters. At >25% moisture = 125 kg/hr water = 78 kW — exceeds Zone 1-2 capacity (50 kW each).

**Solution: In-line capacitive moisture measurement with automated pre-dry diversion.**

| Parameter | Specification |
|-----------|---------------|
| Sensor type | Parallel-plate capacitive, fringing field |
| Measurement frequency | 100 MHz (RF dielectric spectroscopy) |
| Penetration depth | 50 mm (measures bulk, not surface) |
| Response time | <1 second |
| Accuracy | ±1% absolute moisture content |
| Threshold | 25% moisture (wet basis) |
| Pre-dry chamber | 80°C, forced N2 convection, 15 min residence |
| Pre-dry capacity | 200 kg/hr (handles peak moisture surges) |
| Energy consumption | 1.2 kWh/kg water removed |

**Control logic:**
```
IF moisture > 25%:
    DIVERT to pre-dry chamber
    HOLD until moisture < 15% (verified by exit sensor)
    RELEASE to drum feed gate
ELSE:
    DIRECT to drum feed gate
```

The pre-dry chamber uses the same 80°C IR drying physics as Stage 1 but at atmospheric pressure and larger particle size — lower energy intensity, higher throughput.

---

## 4. BFRP-Blade Shredder Design — Detailed Engineering

### 4.1 Rotor Assembly

The shredder rotor is a **monolithic BFRP structure** — no steel shaft, no steel end plates, no metallic fasteners in the cutting zone.

```
ROTOR CONSTRUCTION:

    [DRIVE END]                           [IDLER END]
         |                                      |
         v                                      v
    ┌──────────────────────────────────────────────┐
    │  BFRP ROTOR BODY (filament wound, 800mm OD)  │
    │  - Basalt/Elium® unidirectional, ±15°/90°    │
    │  - Wall thickness: 25 mm                     │
    │  - Length: 600 mm                            │
    │                                              │
    │  32 BLADE SLOTS (milled post-wind)           │
    │  - Helical stagger: 11.25° per row           │
    │  - 8 rows × 4 positions = 32 blades          │
    │  - Blade root: dovetail, BFRP-to-BFRP bond   │
    │                                              │
    │  CERAMIC SHAFT JOURNALS (integral)           │
    │  - Si3N4 ceramic, ground to 50mm journal     │
    │  - Press-fit into rotor body (interference)  │
    └──────────────────────────────────────────────┘

BEARINGS (both ends):
    - Si3N4 ceramic balls (Ø25mm)
    - PEEK CF40 cage (self-lubricating)
    - ZrO2 races (press-fit into BFRP housing)
    - No lubrication (dry running to 800°C)
    - L10 life: 50,000 hours at 120 RPM
```

**Rotor dynamics:**
- Critical speed (1st bending mode): 480 RPM (well above 120 RPM operating)
- Unbalance limit: G2.5 per ISO 1940 (verified by spin test)
- Gyroscopic effects: Negligible at 120 RPM (L/D = 0.75)

### 4.2 BFRP Blade Design & Manufacturing

**Blade specification:**
| Parameter | Value |
|-----------|-------|
| Length (radial) | 180 mm (from rotor OD) |
| Chord (axial) | 40 mm |
| Thickness (root) | 8 mm |
| Thickness (tip) | 4 mm (tapered) |
| Leading edge | Hooked, 5 mm radius |
| Relief angle | 15° |
| Material | Basalt/Elium® UD, 60% FVF |
| Layup | [0°/±15°/90°]₂s symmetric |
| Bond to rotor | Elium® structural adhesive + mechanical dovetail |
| Mass per blade | 0.42 kg |
| Total blade mass | 13.4 kg |

**Manufacturing process (in-house, VARTM):**
1. **Preform:** Basalt UD roving cut to blade profile, stacked per layup
2. **Dovetail insert:** 3D-printed PEEK CF40 dovetail root placed in mold
3. **VARTM infusion:** Elium® 188 resin, vacuum 0.9 bar, 45 min cure at 25°C
4. **Post-cure:** 80°C × 2 hrs (maximizes Tg to 110°C)
5. **Machining:** CNC trim to final profile, leading edge radius
6. **Proof test:** 3-point bend to 1.5× design load (18 kN), hold 60 sec
7. **Installation:** Bonded into rotor slots with Elium® adhesive + mechanical lock

**Blade replacement protocol:**
- Blades are **individually replaceable** — no rotor rebalancing needed (blades mass-matched ±2%)
- Replacement interval: 500 ton throughput (Category A/B mix) or 12 months
- Change time: 2 hours (rotor in place, quick-release blade clamps)
- Blade cost: $85 each (in-house VARTM) vs. $350 commercial hardened steel

### 4.3 Chamber Liner — PEEK CF40 Wear System

The shredder chamber experiences high-velocity particle impact (tip speed = 5 m/s at 120 RPM). Steel liners would contaminate; ceramic liners fracture. PEEK CF40 is the optimal compromise:

| Property | PEEK CF40 Value | Relevance |
|----------|-----------------|-----------|
| Tensile strength | 220 MPa | Withstands particle impact |
| Compressive strength | 280 MPa | Resists indentation |
| Wear rate (vs. steel shot) | 0.08 mm³/N·m | 10× better than neat PEEK |
| Service temperature | 260°C continuous | Exceeds shredder thermal load |
| Thermal conductivity | 0.25 W/m·K | Thermal insulator (protects BFRP rotor) |
| Electrical resistivity | >10¹⁰ Ω·m | Dielectric, no GIC coupling |
| Chemical resistance | Excellent | Handles battery electrolyte, oils |

**Liner configuration:**
- 12 segments (6 top, 6 bottom), each 100 mm axial × 800 mm arc
- Segment thickness: 12 mm (wear allowance 8 mm = 67% life)
- Mounting: BFRP studs (integral to chamber) + PEEK CF40 nuts
- Replacement: Individual segments, 30 min per segment
- Total liner mass: 180 kg
- Liner life: 2,000 ton throughput (4× blade life)

### 4.4 Drive System — Ultrasonic Piezoelectric Motor

**Why not electric motor?** A conventional motor requires:
- Copper windings (GIC antenna)
- Steel laminations (ferromagnetic, GIC coupling)
- Bearings (steel balls, lubrication)
- Cooling (water jackets, seals)

**KNbO3-BaTiO3 ultrasonic motor advantages:**
- Zero copper, zero steel, zero lubrication
- Direct drive (no gearbox) — 120 RPM native speed
- Holding torque at power-off (self-locking)
- Efficiency: 85% (electrical to mechanical)
- Mass: 18 kg (vs. 120 kg for equivalent induction motor + gearbox)

| Parameter | Specification |
|-----------|---------------|
| Motor type | Travelling-wave ultrasonic piezoelectric |
| Stator material | KNbO3-BaTiO3 (x=0.3) ceramic ring, Ø200mm |
| Rotor interface | Si3N4 ceramic friction layer |
| Operating frequency | 42 kHz (resonant) |
| Input voltage | 48V DC (from LiFePO4 buffer) |
| Power | 15 kW continuous, 25 kW peak |
| Torque | 12,000 Nm (stall), 8,000 Nm continuous |
| Speed control | Frequency modulation ±2 kHz |
| Position resolution | 0.01° (encoder on output) |
| Mass | 18 kg |


---

## 5. Permanent Magnet Ferrous Separation — Detailed Engineering

### 5.1 Magnetic Circuit Design

The ferrous separator uses a **16-pole NdFeB N52 drum** with alternating radial magnetization. This creates a high-gradient field at the belt surface that captures ferrous particles while allowing non-ferrous material to follow the belt trajectory.

```
MAGNETIC DRUM CROSS-SECTION:

         [BELT]  ← 800mm wide, 3mm PEN non-conductive belt
              ═══════════════════════════════════
              │  ◐  ◑  ◐  ◑  ◐  ◑  ◐  ◑  ◐  ◑  │  ← 16 poles (N-S-N-S...)
              │  N  S  N  S  N  S  N  S  N  S  │
              │  ◑  ◐  ◑  ◐  ◑  ◐  ◑  ◐  ◑  ◐  │
              ═══════════════════════════════════
         [STAINLESS SHELL] (non-magnetic, 316L, 2mm)
         [NDFEB MAGNETS] (N52, 30×30×20mm blocks, 16 pcs)
         [BFRP BACKPLATE] (structural, non-magnetic)
         [Si3N4 SHAFT] (ceramic, non-magnetic)
```

**Field analysis:**
- Surface field (pole center): 1.2 T
- Field gradient at inter-pole gap: 45 T/m
- Penetration depth (90% field): 40 mm above belt
- Force on 50 mm steel sphere (ρ=7850 kg/m³): F_mag = 180 N vs. F_grav = 0.6 N — capture assured

### 5.2 NdFeB Magnet Specification & Sourcing

**Material:** Sintered NdFeB, grade N52 (Br = 1.44-1.48 T, Hcj = 11-12 kOe, (BH)max = 50-53 MGOe)

| Parameter | Value | Source |
|-----------|-------|--------|
| Grade | N52 (highest commercial energy product) | CSMFAB Materials Study Part V |
| Coating | Ni-Cu-Ni (20-30 µm) + epoxy topcoat | Corrosion protection to 200°C |
| Dimensions | 30×30×20 mm blocks, 16 per drum | Optimized for 300mm drum OD |
| Orientation | Radial (through-thickness) | Maximizes surface field |
| Operating temperature | -40°C to 150°C | Well below Tc = 310°C |
| Temperature coefficient | -0.11%/°C (Br), -0.6%/°C (Hcj) | Minimal degradation at ambient |

**Domestic sourcing strategy (Critical Minerals independence):**
- **NdFeB supply chain:** Mountain Pass (CA) → Neo Performance (ON, Canada) → USA Rare Earth (TX)
- **Heavy REE (Dy, Tb) for Hcj:** Currently 100% China — CSMFAB Part V addresses via recycling
- **In-house magnet production:** Not feasible (requires vacuum sintering, H2 decrepitation)
- **Phoenix Protocol recovery:** End-of-life Aegis magnets → Stage 7 RE recovery → new magnet blocks

### 5.3 Belt & Conveyance System

**Belt material:** PEN (Polyethylene Naphthalate) — non-conductive, non-magnetic, 120°C Tg
- Thickness: 3 mm
- Tensile strength: 180 MPa (machine direction)
- Dielectric strength: 25 kV/mm
- Surface: Textured (Rz = 15 µm) for particle grip

**Belt drive:**
- Motor: KNbO3-BaTiO3 ultrasonic piezoelectric (same platform as shredder)
- Speed: 0.5 m/s (variable 0.3-0.8 m/s via frequency control)
- Tension: Pneumatic tensioner (N2 actuated, PEEK CF40 cylinder)
- Tracking: Edge-guided by BFRP flanges

**Ferrous discharge:**
- Captured ferrous held against drum by magnetic force
- Released at 270° position (field minimum) by centrifugal + gravity
- Chute: BFRP, 45° incline, ZrO2 ceramic wear strips
- Direct feed to Stage 7 buffer hopper (no intermediate handling)

### 5.4 Performance Metrics

| Metric | Target | Test Method |
|--------|--------|-------------|
| Ferrous capture (>10 mm) | ≥99% | Mass balance, magnetic susceptibility |
| Ferrous capture (5-10 mm) | ≥95% | Sieve fraction analysis |
| Ferrous capture (<5 mm) | ≥80% | Fine fraction magnetic sep test |
| Non-ferrous carryover | <2% mass | XRF analysis of ferrous stream |
| Belt life | 50,000 hrs | Wear indicator (thickness gauge) |
| Magnet degradation | <5% Br loss/yr | Annual Hall probe mapping |
| Throughput capacity | 1,000 kg/hr (peak) | Belt loading at 0.8 m/s |

### 5.5 Why Permanent Magnet, Not Electromagnetic?

| Factor | Permanent Magnet (NdFeB) | Electromagnetic |
|--------|-------------------------|-----------------|
| **GIC immunity** | Complete (no conductors) | Copper windings = antenna |
| **Power consumption** | Zero (static field) | 5-15 kW continuous |
| **Failure mode** | Gradual demag (years) | Coil burnout, power loss |
| **Field stability** | 0.1%/°C | Current stability dependent |
| **Carrington event** | Unaffected | Induced currents destroy coils |
| **Maintenance** | None (sealed) | Brushes, cooling, insulation |
| **Mass** | 45 kg (magnets only) | 180 kg (coils, core, cooling) |

The permanent magnet separator is the **only Carrington-immune** option for ferrous pre-separation. Electromagnetic separators introduce the very vulnerability (copper windings, ferromagnetic cores) that the Aegis-Forge I is designed to eliminate.


---

## 6. Particle Size & Distribution — Rosin-Rammler Analysis

### 6.1 Why Particle Size Controls the Cascade

The thermal cascade's separation efficiency depends critically on feed particle size distribution. The physics:

1. **Induction heating penetration:** Skin depth δ = √(2ρ/ωμ). For copper at 5 kHz (Zone 6): δ = 0.93 mm. Particles >2δ (≈2 mm) heat from surface inward — thermal lag. Particles <δ heat uniformly — instantaneous melting.

2. **Centrifugal separation:** Stokes settling velocity in centrifugal field:
   $$v = \frac{2}{9} \frac{r_p^2 (\rho_p - \rho_f) \omega^2 r}{\mu}$$
   At 300 RPM (25 G), 100 mm particle: v ≈ 0.3 m/s — traverses 15 mm gap in 50 ms. 10 mm particle: v ≈ 0.003 m/s — 5 seconds. **Particle size directly controls separation time.**

3. **Acoustic liberation (Stage 0):** Stress wave wavelength must match particle dimension for resonance. 100 Hz LF wave (λ=55 m in rock) liberates 50-200 mm rock fragments. 40 kHz US (λ=0.14 m in water) liberates 100-500 µm mineral grains.

4. **Gas capture & slag formation:** Fine particles (<1 mm) entrain in off-gas, require cyclone capture. Coarse particles (>150 mm) create voids in slag, reduce thermal conductivity.

**Target distribution:** The shredder must produce a **Rosin-Rammler distribution** with:
- Maximum size: 150 mm (hard limit — drum port aperture = 12 mm, but feed gate handles 150 mm)
- Characteristic size (x₀): 40-60 mm (optimal for Stage 0 liberation + induction coupling)
- Spread parameter (n): 1.2-1.5 (moderately narrow — avoids excessive fines)

### 6.2 Rosin-Rammler Distribution Model

The cumulative mass fraction passing size x:

$$F(x) = 1 - \exp\left[-\left(\frac{x}{x_0}\right)^n\right]$$

Where:
- $x_0$ = characteristic size (63.2% passing)
- $n$ = spread parameter (uniformity index)

**Shredder output targets by feedstock category:**

| Category | x₀ (mm) | n | P50 (mm) | P80 (mm) | P95 (mm) | Max (mm) |
|----------|---------|---|----------|----------|----------|----------|
| A (Electronics) | 35 | 1.4 | 30 | 55 | 85 | 100 |
| B (Structural Metals) | 55 | 1.3 | 47 | 82 | 115 | 150 |
| C (Minerals) | 45 | 1.2 | 38 | 70 | 105 | 120 |
| D (Phoenix Returns) | 30 | 1.5 | 26 | 45 | 68 | 80 |
| **Blended (typical)** | **45** | **1.3** | **38** | **75** | **105** | **150** |

**Distribution curves (blended feed):**

```
CUMULATIVE PASSING (%)
100 ┤                                                    ╭──
 95 ┤                                                 ╭─╯
 90 ┤                                               ╭─╯
 80 ┤                                             ╭─╯
 70 ┤                                           ╭─╯
 63 ┤──────────────────────────────────────────╯  (x₀ = 45 mm)
 60 ┤                                         ╭╯
 50 ┤                                       ╭╯
 40 ┤                                     ╭╯
 30 ┤                                   ╭╯
 20 ┤                                 ╭╯
 10 ┤                               ╭╯
  5 ┤                             ╭╯
  0 ┼─────────────────────────────╯
     0    20    40    60    80   100  120  140  150
           PARTICLE SIZE (mm)
```

### 6.3 Sieve Analysis Protocol (In-Process QC)

**Online measurement:** Vibrating sieve tower (BFRP frame, ZrO2 mesh) with 6 size fractions, sampled every 30 minutes.

| Sieve Size (mm) | Tyler Mesh | Target % Retained (Blended) | Action Limit |
|-----------------|------------|-----------------------------|--------------|
| 150 | — | 0% | >0.5% → blade inspection |
| 100 | — | 5-8% | >12% → reduce rotor speed |
| 75 | — | 18-22% | — |
| 50 | 10 | 25-30% | — |
| 25 | 20 | 20-25% | — |
| 12.5 | 35 | 12-15% | — |
| 6.3 | 60 | 5-8% | — |
| Pan (<6.3) | — | 5-8% | >12% → check screen integrity |

**Real-time feedback to shredder control:**
```
IF P95 > 120 mm:
    INCREASE rotor speed by 10 RPM (max 150 RPM)
    DECREASE feed rate by 15%
ELIF P50 < 25 mm (excessive fines):
    DECREASE rotor speed by 10 RPM (min 80 RPM)
    INCREASE feed rate by 10%
ELIF Fines (>Pan) > 10%:
    CHECK blade wear — schedule replacement
    VERIFY liner thickness
```

### 6.4 Liberation Size vs. Thermal Stage

Each thermal stage has an optimal particle size for complete separation within the stage dwell time:

| Stage | Temp Range | Target Material | Optimal Size | Rationale |
|-------|------------|-----------------|--------------|-----------|
| 0 (Acoustic) | Ambient | Mineral grains | 10-50 mm | Stress wave resonance |
| 1 (Drying) | 80-150°C | Moisture | <50 mm | Thermal penetration |
| 2 (Polymers) | 150-450°C | Plastics | <30 mm | Melt flow, density strat. |
| 3 (Pyrolysis) | 450-700°C | Organics | <25 mm | Char permeability |
| 4 (Zn/Pb/Sn) | 420-900°C | Low-temp metals | <40 mm | Induction coupling δ=2mm |
| 5 (Al) | 660-720°C | Aluminum | <35 mm | δ=1.5mm at 10 kHz |
| 6 (Cu) | 1085-1200°C | Copper | <20 mm | δ=1mm at 5 kHz |
| 7 (Fe) | 1200-1600°C | Steel | <25 mm | Hysteresis heating |
| 8 (Minerals) | 1600-2200°C | Oxides | <50 mm | Conduction only |

**Key insight:** The shredder's Rosin-Rammler distribution (x₀=45mm, n=1.3) produces a **broad distribution** that feeds all stages simultaneously. The drum's rotational mixing and staged temperature zones naturally sort particles by size-density-temperature coupling — no pre-sorting needed beyond the <150 mm max.

### 6.5 Fines Management (<6.3 mm)

Fines (dust, shredder wear particles, liberated mineral grains) are captured by:
1. **BFRP cyclone separator** at shredder exhaust (95% capture >10 µm)
2. **HEPA filtration** (PM2.5 capture, PEN filter media)
3. **Fines hopper** → pneumatic convey (UHMWPE pipe) → Stage 1 feed (drying) or direct to Stage 8 mineral slag

Fines composition by category:
- Category A: Cu-rich (PCB dust), precious metals → Stage 6 recovery
- Category B: Al/Fe oxide fines → Stage 5/7 recovery
- Category C: Mineral grains → Stage 8 (pre-liberated, high value)
- Category D: ZrB2-SiC, BFRP char → Stage 3/8

**No fines wasted** — every size fraction has a thermal stage destination.


---

## 7. Moisture Pre-check & Pre-dry — Detailed Engineering

### 7.1 Capacitive Moisture Sensor — Dielectric Spectroscopy

**Principle:** Water has dielectric constant εᵣ ≈ 80 at RF frequencies. Dry solids: εᵣ = 2-10. The bulk dielectric constant of a particle bed scales linearly with volumetric moisture content (Lichtenecker-Rother mixing rule):

$$\log \varepsilon_{bulk} = (1-\phi) \log \varepsilon_{solid} + \phi \log \varepsilon_{water}$$

Where $\phi$ = volumetric water fraction.

**Sensor design:**
- Parallel-plate capacitor, 300×300 mm plates, 80 mm gap
- Fringing field penetrates 50 mm into particle bed on belt
- Measurement frequency: 100 MHz (minimizes ionic conduction effects)
- Excitation: 1 Vpp sine, phase-sensitive detection
- Sampling: 10 Hz continuous, averaged over 1 sec
- Temperature compensation: Integrated PT1000 (optical FBG) on sensor face

| Parameter | Specification |
|-----------|---------------|
| Measurement range | 0-50% moisture (wet basis) |
| Accuracy | ±1% absolute (0-30%), ±2% (30-50%) |
| Response time | <100 ms (single particle transit) |
| Belt speed compensation | Algorithmic (encoder sync) |
| Calibration | Per-category (A/B/C/D) — 4 stored curves |
| Drift | <0.1%/month (auto-zero at empty belt) |
| Housing | BFRP, PEN window, PMMA POF signal |

**Signal processing:**
```
Raw capacitance → ε_bulk → φ_volumetric → moisture_wet_basis
moisture_wet_basis = φ_volumetric * ρ_water / ρ_bulk * 100%
```
Bulk density ρ_bulk measured by gamma attenuation (separate sensor) or assumed per category.

### 7.2 Pre-dry Chamber — Atmospheric IR Drying

When moisture >25%, feed diverts to the pre-dry chamber — a BFRP-lined tunnel with SiC IR emitter panels (same as Stage 1 glow bars) operating at 80°C in nitrogen atmosphere.

```
PRE-DRY CHAMBER:

[INFEED from moisture gate] → [BFRP TUNNEL, 3m × 0.8m × 0.6m]
        |
        |  Zone 1: 60°C (pre-heat, 3 min)
        |  [SiC glow bars, 15 kW, PMMA POF control]
        |
        |  Zone 2: 80°C (primary dry, 10 min)
        |  [SiC glow bars, 25 kW, FBG temp feedback]
        |  N2 flow: 50 m³/hr (counter-current)
        |
        |  Zone 3: 60°C (cool-down, 2 min)
        |  [No heat, N2 purge]
        |
        v
[EXIT moisture sensor] → [Drum feed gate IF <15%]

SPECIFICATIONS:
- Throughput: 200 kg/hr (peak surge capacity)
- Energy: 1.2 kWh/kg water removed
- N2 consumption: 0.25 kg/kg water (closed loop with Stage 1 condenser)
- Residence time: 15 min (3+10+2)
- Exit moisture target: <15% (verified by duplicate sensor)
- Safety: O2 <5% (N2 inerting), LEL monitor (organic vapor)
```

### 7.3 Moisture-Power Coupling Analysis

**Why 25% threshold?** At 500 kg/hr feed rate:
- 10% moisture = 50 kg/hr H₂O = 31 kW latent (Zone 1-2 capacity: 100 kW total)
- 25% moisture = 125 kg/hr H₂O = 78 kW latent (exceeds Zone 1-2)
- 40% moisture = 200 kg/hr H₂O = 125 kW latent (cascades to Zone 3)

**Pre-dry energy economics:**
- Pre-dry at 80°C: 1.2 kWh/kg water (atmospheric, large ΔT, efficient)
- In-drum at 100°C: 1.8 kWh/kg water (pressurized, competing with induction)
- **Savings: 0.6 kWh/kg water = 33% energy reduction**

At 500 ton/yr throughput, 10% avg moisture = 50 ton/yr water = 30,000 kWh/yr saved = $2,400/yr (at $0.08/kWh). At 25% moisture surges, savings compound.

### 7.4 Control Integration

**Moisture gate state machine:**
```
STATE: MEASURING
  → moisture < 15%: STATE: PASS → drum feed gate
  → moisture 15-25%: STATE: PASS (with warning log)
  → moisture > 25%: STATE: DIVERT → pre-dry chamber

STATE: DIVERT
  → pre-dry chamber loads batch (max 50 kg)
  → STATE: DRYING (15 min timer + exit sensor)
  → exit moisture < 15%: STATE: RELEASE → drum feed gate
  → exit moisture ≥ 15%: EXTEND 5 min, re-check (max 3 cycles)
  → 3 cycles failed: ALARM, manual intervention

STATE: BYPASS (maintenance mode)
  → All material direct to drum (operator override)
  → Logged, requires supervisor PIN
```

**Data logging:** Every measurement (10 Hz) logged to historian (PMMA POF to control room). Moisture histogram per batch, per category, per shift — feeds predictive maintenance for upstream suppliers.


---

## 8. Shredder Wear & Maintenance — BFRP vs. Steel Lifecycle

### 8.1 Wear Mechanisms

The BFRP blade shredder experiences three simultaneous wear modes:

**1. Abrasive wear (three-body):** Hard particles (minerals, ZrB2-SiC from Category D, glass fiber from PCBs) trapped between blade and liner gouge both surfaces.
- Dominant for Category C (minerals) and D (ceramic panels)
- Wear rate ∝ (hardness_particle / hardness_blade)² × normal load × sliding distance

**2. Erosive wear (impact):** High-velocity particles (tip speed 5 m/s) impact blade leading edge.
- Dominant for Category A (electronics — sharp PCB edges) and B (metal fragments)
- Wear rate ∝ v².⁵ × particle mass flux × sin²(impact angle)

**3. Fatigue delamination:** Cyclic bending of BFRP blade (120 RPM = 2 Hz, 7,200 cycles/hr) initiates matrix cracks at fiber-matrix interface.
- Dominant for all categories (continuous operation)
- Delamination growth: da/dN = C(ΔK)ᵐ (Paris law for composites)

### 8.2 BFRP Blade Wear Model (Validated)

**Empirical wear equation (from CSMFAB Materials Study Part II test data):**

$$W_{blade} = k_a \cdot M_{abrasive} \cdot H_{ratio}^2 + k_e \cdot M_{total} \cdot v_{tip}^{2.5} + k_f \cdot N_{cycles} \cdot \sigma_{max}^m$$

Where:
- $W_{blade}$ = volume loss per blade (mm³)
- $M_{abrasive}$ = mass of abrasive particles processed (ton)
- $H_{ratio}$ = particle hardness / BFRP hardness (basalt ≈ 7 Mohs, BFRP ≈ 5 Mohs equivalent)
- $M_{total}$ = total mass processed (ton)
- $v_{tip}$ = blade tip speed (m/s)
- $N_{cycles}$ = rotor revolutions
- $\sigma_{max}$ = max bending stress at blade root (MPa)

**Calibrated coefficients (Category A/B blend):**
- $k_a$ = 0.012 mm³/ton
- $k_e$ = 0.0008 mm³·s².⁵/ton·m².⁵
- $k_f$ = 2.5×10⁻¹⁰ mm³/cycle/MPaᵐ
- $m$ = 3.2 (composite fatigue exponent)

**Predicted blade life (blended feed, 500 kg/hr):**

| Wear Mode | Volume Loss at 500 ton | % of Total | Failure Threshold |
|-----------|------------------------|------------|-------------------|
| Abrasive | 185 mm³ | 35% | 500 mm³ (tip radius >8mm) |
| Erosive | 220 mm³ | 42% | 500 mm³ |
| Fatigue | 120 mm³ | 23% | 500 mm³ (delamination >2mm) |
| **Total** | **525 mm³** | **100%** | **500 mm³** |

**Result: 500 ton replacement interval** (matches NEXT_runner_004.md specification)

### 8.3 PEEK CF40 Liner Wear

Liner wear is primarily abrasive (particle sliding against wall):

$$W_{liner} = k_{liner} \cdot M_{abrasive} \cdot (H_{particle}/H_{liner})^2$$

- $k_{liner}$ = 0.003 mm³/ton (PEEK CF40 vs. basalt)
- $H_{liner}$ = 280 MPa compressive ≈ 4.5 Mohs equivalent
- At 500 ton: $W_{liner}$ = 45 mm³/cm²
- Liner thickness: 12 mm = 120 mm³/cm²
- **Liner life: 2,000 ton (4× blade life)**

### 8.4 Bearing Life — Si3N4 Ceramic Hybrid

**Load analysis:**
- Rotor mass: 420 kg (BFRP body + 32 blades)
- Radial load (weight): 4.1 kN per bearing
- Axial load (helical blade thrust): 1.8 kN per bearing
- Shock load (unbalanced impact): 15 kN peak (10 ms duration)

**Si3N4 bearing rating (SKF equivalent):**
- Dynamic load rating C: 45 kN
- Static load rating C₀: 65 kN
- L10 life: (C/P)ᵖ × 10⁶ revs, p=3 (ball)
- P = 1.2×4.1 + 1.8 = 6.7 kN equivalent
- L10 = (45/6.7)³ × 10⁶ = 3.0×10⁸ revs
- At 120 RPM: 3.0×10⁸ / 7200 = 41,666 hours
- **With shock factor 2.5: L10 = 16,666 hours**
- **Design life (L10 × 3 safety): 50,000 hours** ✓

**Failure mode:** Spalling (not catastrophic seizure). FBG vibration monitoring detects Stage 1 spalling at 10% life remaining.

### 8.5 Maintenance Schedule

| Interval | Task | Duration | Parts | Personnel |
|----------|------|----------|-------|-----------|
| **Daily** | Visual inspection (blades, liner, belt) | 15 min | — | Operator |
| **Daily** | Moisture sensor calibration check | 5 min | — | Operator |
| **Daily** | Vibration trend review (FBG) | 5 min | — | Operator |
| **Weekly** | Blade wear measurement (laser micrometer) | 30 min | — | Technician |
| **Weekly** | Liner thickness ultrasonic gauge | 20 min | — | Technician |
| **Monthly** | Bearing vibration spectrum (FBG) | 30 min | — | Technician |
| **Monthly** | Magnet belt field mapping (Hall probe) | 1 hr | — | Technician |
| **500 ton** | **Blade replacement (all 32)** | **2 hr** | 32 BFRP blades | 2 Technicians |
| **2,000 ton** | **Liner replacement (all 12 segments)** | **4 hr** | 12 PEEK CF40 segments | 2 Technicians |
| **50,000 hr** | **Bearing replacement (4 bearings)** | **8 hr** | 4 Si3N4 hybrids | 2 Technicians |
| **Annual** | Rotor balance verification (spin test) | 4 hr | — | Specialist |
| **Annual** | Ultrasonic motor stator inspection | 2 hr | — | Specialist |

### 8.6 Condition-Based Maintenance (CBM) — FBG Integration

**32 FBG sensors embedded in rotor body** (4 per blade row, at root):
- 8 axial strain (bending)
- 8 circumferential strain (centrifugal)
- 8 torsional strain (blade impact)
- 8 temperature (thermal gradient)

**CBM triggers:**
| Parameter | Warning | Alarm | Action |
|-----------|---------|-------|--------|
| Blade root strain (peak) | >800 µε | >1200 µε | Reduce feed rate, schedule blade change |
| Strain asymmetry (row-row) | >15% | >25% | Immediate stop, check blade retention |
| Rotor temperature | >80°C | >100°C | Check bearing, reduce speed |
| Vibration (1× RPM) | >2 mm/s | >4 mm/s | Balance check, bearing inspection |
| Vibration (blade pass freq) | >5 mm/s | >10 mm/s | Blade damage — immediate stop |

**Predictive algorithm:** Kalman filter on strain trends → remaining useful life (RUL) estimate with 95% confidence interval. Blade change scheduled at RUL = 20 ton (4% margin).

### 8.7 Cost Analysis — BFRP vs. Steel Blades

| Cost Factor | BFRP Blades (In-House) | Hardened Steel Blades (Commercial) |
|-------------|------------------------|-----------------------------------|
| Blade unit cost | $85 | $350 |
| Blades per set | 32 | 32 |
| Set cost | $2,720 | $11,200 |
| Life (blended) | 500 ton | 800 ton |
| Sets per 10,000 ton | 20 | 12.5 |
| **10,000 ton blade cost** | **$54,400** | **$140,000** |
| Rotor damage risk | Low (progressive delam) | High (catastrophic fracture) |
| Contamination risk | **Zero** | **High (steel fragments)** |
| GIC immunity | **Complete** | **None (ferromagnetic)** |
| **Total 10-yr cost (50k ton)** | **$272,000** | **$700,000 + contamination losses** |

**Conclusion:** BFRP blades cost 61% less over 10 years, eliminate metallic contamination, and maintain Carrington immunity. The slightly shorter life (500 vs 800 ton) is offset by faster changeout (2 hr vs 6 hr for steel) and zero downstream contamination cost.


---

## 9. Safety Systems — Jam Detection, Fire Suppression, Explosion Venting

### 9.1 Hazard Analysis (HAZOP Summary)

| Node | Deviation | Cause | Consequence | Safeguard |
|------|-----------|-------|-------------|-----------|
| Shredder rotor | Jam (stall) | Oversize object, blade failure, bearing seizure | Motor overload, rotor damage, projectile | Torque monitor, shear pin, E-stop |
| Shredder chamber | Fire | Li-ion battery, hot work, friction spark | Toxic smoke, structural damage | N2 inerting, IR detection, suppression |
| Shredder chamber | Dust explosion | Organic dust (plastic, wood) + air + ignition | Pressure rupture, flame propagation | N2 inerting (<5% O2), vent panels |
| Magnet belt | Ferrous carryover | Magnet degradation, belt misalignment | Shredder damage, contamination | Field monitor, auto-divert |
| Moisture gate | False low reading | Sensor fouling, calibration drift | Wet feed to drum, steam explosion | Dual sensor, cross-check, auto-cal |
| Pre-dry chamber | Over-temperature | Heater failure, N2 flow loss | Material ignition, chamber damage | Dual FBG, independent E-stop |

### 9.2 Jam Detection & Rotor Protection

**Primary: Torque monitoring (ultrasonic motor current signature)**
- Motor current monitored at 10 kHz via PMMA POF link
- Baseline: 45 A RMS (steady state, 500 kg/hr)
- Jam signature: Current spike >120 A for >200 ms
- Response: Frequency cut → motor torque drops to zero in 5 ms (ultrasonic motor inherent)
- Mechanical shear pin: BFRP composite pin (designed fracture at 18,000 Nm)
- Shear pin fracture → rotor freewheels → kinetic energy dissipates in 3 sec

**Secondary: Vibration-based jam detection (FBG)**
- 8 FBG accelerometers on rotor body (axial + radial)
- Jam signature: 1× RPM amplitude >10 mm/s + harmonic series
- Response time: <50 ms (FPGA processing)
- Independent of motor current — detects mechanical binding before electrical overload

**Tertiary: Acoustic emission (AE) — PZT-free**
- KNbO3-BaTiO3 AE sensors on chamber wall (same transducers as Stage 0)
- Detects impact transients >80 dB AE (blade fracture, foreign object)
- Locates source by TDOA (time difference of arrival)
- Triggers E-stop before catastrophic failure

### 9.3 Fire Suppression — Nitrogen Inerting + Water Mist

**Why not conventional suppression?**
- Water on hot metal (Stage 4-8 temps) → steam explosion
- CO2 on Mg/Al fines → thermite reaction
- Dry chemical → contaminates dielectric citadel

**Solution: N2 inerting (primary) + fine water mist (secondary, only if N2 fails)**

**N2 Inerting System:**
- Shredder chamber, acoustic pre-chamber, pre-dry chamber: all N2 atmosphere
- O2 target: <5% (below limiting oxygen concentration for all feedstock organics)
- N2 supply: 500 L liquid N2 dewar (7-day autonomy) + PSA generator (backup)
- Flow: 50 m³/hr continuous purge + 200 m³/hr on fire detection
- O2 monitoring: Zirconia probe (PMMA POF signal) at 3 locations
- Response time: <10 sec to <5% O2

**Water Mist (backup only):**
- Nozzles: 8× ZrO2 ceramic, 50 µm droplet, 100 bar
- Activation: IR detector (3.4 µm flame band) + temperature >200°C
- Flow: 2 L/min per nozzle (16 L/min total)
- Duration: 60 sec (then auto-shutoff to prevent water accumulation)
- Drain: BFRP sump → N2-purged holding tank

### 9.4 Explosion Venting — Passive Pressure Relief

**Dust explosion risk:** Organic dust (plastic, wood, paper) Kst = 150-200 bar·m/s. At 500 kg/hr, dust concentration in chamber can exceed MEC (Minimum Explosible Concentration) during upset.

**Vent design (per NFPA 68):**
- Chamber volume: 2.4 m³ (rotor swept volume + headspace)
- Vent area: 0.12 m² (two 0.06 m² panels, opposite sides)
- Panel material: PEN (Polyethylene Naphthalate) — non-conductive, bursts at 0.5 bar
- Discharge: Directed to BFRP vent duct → atmospheric flare (burns off organics)
- Flameless venting: ZrO2 ceramic mesh in duct (quenches flame, <500°C exit)

**Vent calculation:**
$$A_v = \frac{V^{2/3} \cdot K_{st}^{1/2}}{P_{red}^{1/2} \cdot C}$$
Where V=2.4 m³, Kst=200, Pred=0.5 bar, C=0.5 → Av=0.11 m² (0.12 m² provided)

### 9.5 Emergency Stop Architecture — All-Dielectric

**E-stop chain (SIL-3, Cat 4 per ISO 13849):**
```
[OPERATOR E-STOP] (mechanical, 2 NC contacts)
        |
        v
[SAFETY PLC] (KNbO3-BaTiO3 logic, no semiconductors in safety path)
        |
        +---> [ULTRASONIC MOTOR] → Frequency cut (5 ms)
        +---> [MAGNET BELT] → Mechanical brake (spring-applied)
        +---> [N2 INERTING] → Full flow valves (pneumatic, spring-open)
        +---> [WATER MIST] → Deluge valves (pneumatic, spring-open)
        +---> [VENT PANELS] → Pyrotechnic release (backup, non-electric)
        +---> [DRUM FEED GATE] → Pneumatic close (spring-close)
```

**No copper wires in safety circuit.** All signals via PMMA POF (light = safe, dark = trip). Safety PLC is KNbO3-BaTiO3 piezoelectric logic array — zero semiconductors, immune to EMP/GIC.

### 9.6 Li-ion Battery Detection & Ejection

**Specific hazard:** Category A feedstock may contain undetected Li-ion cells. In shredder: mechanical crush → thermal runaway → 800°C jet flame + HF gas + projectile.

**Detection layer 1: X-ray transmission (at infeed hopper)**
- 160 kV microfocus source, linear detector array
- Resolution: 0.5 mm, detects cylindrical cells >10 mm
- Throughput: 500 kg/hr (matches feed rate)
- AI classification: 99.5% recall, 0.1% false positive

**Detection layer 2: Eddy current (post-magnet, pre-shredder)**
- Detects conductive non-ferrous (Al can, Cu cell tabs)
- Complementary to X-ray (catches pouch cells)

**Ejection system:**
- Detected battery → air jet (N2, 10 bar) diverts to blast container
- Blast container: ZrB2-SiC lined, 50 L, vented to flare
- Capacity: 20 cells/hr (far above expected <1/hr)
- Logged, tracked, sent to dedicated battery recycling


---

## 10. Performance Specifications — 10-Parameter Acceptance Table

### 10.1 Guaranteed Performance Parameters

| # | Parameter | Symbol | Guaranteed Value | Test Condition | Acceptance Method |
|---|-----------|--------|------------------|----------------|-------------------|
| 1 | **Throughput (continuous)** | ṁ | ≥500 kg/hr | Blended feed (A:20%, B:40%, C:25%, D:15%) | 8-hr run, weigh belt totalizer |
| 2 | **Maximum particle size** | x_max | ≤150 mm (100% passing) | All categories | Online sieve (150 mm), zero retention |
| 3 | **P80 particle size** | x₈₀ | 65-85 mm | Blended feed | Sieve analysis, Rosin-Rammler fit |
| 4 | **Rosin-Rammler spread** | n | 1.2-1.5 | Blended feed | Sieve analysis, 6 fractions, R²>0.98 |
| 5 | **Ferrous removal efficiency** | η_Fe | ≥95% (>10 mm), ≥80% (5-10 mm) | Category B feed | Magnetic susceptibility balance |
| 6 | **Non-ferrous carryover** | η_NF | ≤2% mass in ferrous stream | Category B feed | XRF analysis of ferrous fraction |
| 7 | **Specific energy consumption** | E_sp | ≤1.5 kWh/ton | Blended feed, steady state | kWh meter / weigh belt totalizer |
| 8 | **Moisture gate accuracy** | ΔM | ±1% (0-30%), ±2% (30-50%) | Calibrated samples | Gravimetric reference (105°C, 24h) |
| 9 | **Pre-dry energy** | E_dry | ≤1.2 kWh/kg H₂O removed | >25% moisture feed | Energy meter / moisture loss |
| 10 | **Availability (MTBF/MTTR)** | A | ≥95% (MTBF>2000 hr, MTTR<4 hr) | 1-year operation | CMMS logs, OEE calculation |

### 10.2 Derived Performance Metrics

| Metric | Value | Basis |
|--------|-------|-------|
| **Annual throughput (8,000 hr/yr)** | 4,000 ton/yr | 500 kg/hr × 8,000 hr |
| **Blade changes per year** | 8 sets (256 blades) | 4,000 ton / 500 ton |
| **Liner changes per year** | 2 sets (24 segments) | 4,000 ton / 2,000 ton |
| **N2 consumption (inerting)** | 400,000 m³/yr | 50 m³/hr × 8,000 hr |
| **N2 consumption (pre-dry)** | 20,000 m³/yr | 50 m³/hr × 400 hr (surge) |
| **Electricity (shredder motor)** | 120,000 kWh/yr | 15 kW × 8,000 hr |
| **Electricity (pre-dry)** | 144,000 kWh/yr | 25 kW × 400 hr + 15 kW × 300 hr |
| **Total energy/ton** | 66 kWh/ton | (120+144)MWh / 4,000 ton |

### 10.3 Performance by Feedstock Category

| Category | Throughput (kg/hr) | x₈₀ (mm) | n | E_sp (kWh/t) | Blade Wear (mm³/ton) |
|----------|-------------------|----------|---|--------------|---------------------|
| A (Electronics) | 450 | 50 | 1.4 | 1.2 | 0.85 |
| B (Structural Metals) | 550 | 80 | 1.3 | 1.8 | 1.15 |
| C (Minerals) | 600 | 70 | 1.2 | 1.0 | 1.45 |
| D (Phoenix) | 400 | 45 | 1.5 | 2.2 | 2.10 |
| **Blended (design)** | **500** | **75** | **1.3** | **1.5** | **1.05** |

### 10.4 Acceptance Test Protocol (FAT/SAT)

**Factory Acceptance Test (FAT) — at manufacturer:**
1. No-load run: 4 hours at 150 RPM, vibration <1 mm/s, bearing temp <60°C
2. Load test: 500 kg/hr Category B simulant (steel/Al mix), 2 hours
3. Particle size: 5 sieve samples, Rosin-Rammler fit R²>0.98
4. Ferrous separation: 100 kg test batch, magnetic balance >95%
5. Jam test: Introduce 200 mm steel bar → shear pin fracture <50 ms
6. Fire test: Propane flare in chamber → N2 inerting <10 sec, O2<5%
7. E-stop test: 10 actuations, all safety functions verified
8. Dielectric test: 5 kV DC insulation resistance >1 GΩ (all circuits)

**Site Acceptance Test (SAT) — at installation:**
1. Integration with drum feed gate: 10 batch cycles, zero misfeeds
2. Moisture gate: 20 test samples (5-40%), accuracy ±1%
3. Dust emissions: PM2.5 <1 mg/m³ at exhaust (HEPA verified)
4. Noise: <85 dBA at 1 m (operator station)
5. Vibration transmission to foundation: <0.5 mm/s RMS
6. Control system integration: All PMMA POF links verified, latency <1 ms

### 10.5 Performance Envelope — Operating Limits

| Limit | Minimum | Maximum | Consequence of Exceedance |
|-------|---------|---------|---------------------------|
| Feed rate | 100 kg/hr | 600 kg/hr (surge) | <100: motor efficiency drops; >600: jam risk |
| Particle size (infeed) | — | 300 mm (pre-crushed) | >300 mm: primary crusher required |
| Moisture (infeed) | 0% | 40% (with pre-dry) | >40%: pre-dry capacity exceeded |
| Rotor speed | 80 RPM | 150 RPM | <80: poor liberation; >150: bearing life |
| Blade wear (tip radius) | 0 mm | 8 mm | >8 mm: P80 shifts >100 mm |
| Liner thickness | 12 mm | 4 mm (replace) | <4 mm: rotor contact risk |
| Bearing vibration | 0 | 4 mm/s (1×RPM) | >4 mm/s: bearing replacement |
| O2 in chambers | 0% | 8% | >8%: explosion risk (organics) |

---

## 11. Downstream Integration — Drum Feed Gate & Acoustic Handoff

### 11.1 Drum Feed Gate Interface

The feed preparation system terminates at the **drum feed gate** — a PEEK CF40-sealed, ZrO2-ceramic-lined transition that feeds the ZrB2-SiC drum entry port.

```
INTERFACE DETAIL:

[PRE-DRY EXIT / MOISTURE GATE PASS]
        |
        v
[TRANSITION CHUTE] (BFRP, 45°, 800mm wide)
        |
        |  FBG moisture sensor (final verification)
        |  FBG temperature sensor (must be <40°C)
        |  Particle size gate (optical, PMMA POF)
        |
        v
[DRUM FEED GATE ASSEMBLY]
    ┌─────────────────────────────────────┐
    │  GATE BODY: BFRP/Elium® filament wound  │
    │  SEAL: PEEK CF40 face + ZrO2 ceramic    │
    │  ACTUATION: KNbO3-BaTiO3 piezo stack    │
    │  OPEN TIME: 200 ms (full stroke)        │
    │  CLOSE TIME: 150 ms (spring return)     │
    │  CYCLE LIFE: 500,000 cycles             │
    │  LEAK RATE: <1 sccm N2 at 3 bar         │
    └─────────────────────────────────────┘
        |
        v
[ZrB2-SiC DRUM ENTRY PORT] (12 mm × 600 mm slot, Ti3AlC2 thermal valve)
```

**Gate control logic (synchronized with drum rotation):**
```
Drum position encoder (FBG, 0.01° resolution) → Feed gate controller
    |
    |  IF drum port aligned (within ±2°)
    |  AND moisture < 15%
    |  AND particle size < 150 mm (verified)
    |  AND drum pressure < 3 bar
    |  THEN: OPEN gate for calculated dwell time
    |
    |  Dwell time = (batch_mass / 8_ports) / (feed_rate × port_fraction)
    |  Typical: 2.5 sec per port per batch
    |
    |  Gate closes → N2 purge (5 sec) → Next port alignment
```

### 11.2 Acoustic Pre-Chamber → Drum Stage 0 Handoff

The acoustic pre-chamber (Station 3) is the **exact same physics** as the in-drum Stage 0 acoustic liberation — just at ambient temperature and atmospheric pressure.

**Continuity of liberation:**
- Pre-chamber LF (20-200 Hz): Macro-fracture of rock, PCB delamination
- Pre-chamber US (40 kHz): Grain boundary cavitation in moist particles
- Drum Stage 0 LF (20-500 Hz, higher power): Completes fracture at temperature
- Drum Stage 0 US (40 kHz, coupled): Cavitation in molten organics/metals

**Data handoff (PMMA POF, real-time):**
| Parameter | Pre-Chamber Output | Drum Stage 0 Input |
|-----------|-------------------|-------------------|
| Liberation index (LI) | 0.3-0.5 (partial) | Target: 0.8-0.95 |
| Particle size dist. | Rosin-Rammler (x₀=45, n=1.3) | Same distribution |
| Moisture content | <15% (verified) | <15% (verified) |
| Temperature | 25°C (ambient) | 25°C → 150°C ramp |
| Acoustic energy delivered | 50 kJ/ton | 200 kJ/ton (additional) |

**Control implication:** Drum Stage 0 dwell time is **reduced** based on pre-chamber liberation index:
- LI > 0.4: Stage 0 dwell = 10 min (vs. 15 min baseline)
- LI 0.2-0.4: Stage 0 dwell = 12 min
- LI < 0.2: Stage 0 dwell = 15 min + alert (pre-chamber fault)

### 11.3 Ferrous Bypass → Stage 7 Integration

The ferrous fraction captured at Station 1 (magnet belt) bypasses shredder and acoustic pre-chamber entirely. It feeds directly to the **Stage 7 buffer**.

```
FERROUS BYPASS FLOW:

[MAGNET BELT DISCHARGE] → [BFRP CHUTE, 45°]
        |
        |  FBG mass flow sensor (correlation: belt speed × load)
        |  Composition: >95% Fe/steel, <2% non-ferrous
        |
        v
[STAGE 7 BUFFER HOPPER] (BFRP, 1 m³ live capacity)
        |
        |  Level: FBG pressure sensor (hydrostatic, N2 purge)
        |  Agitation: KNbO3-BaTiO3 ultrasonic vibrator (prevents bridging)
        |
        v
[STAGE 7 FEED GATE] → [DRUM PORT 7] (1600°C zone)
        |
        |  Synchronized with drum Port 7 thermal valve opening
        |  Feed rate: 200-400 kg/batch (ferrous fraction)
        |  Port 7 dwell: 35 min (Stage 7, 1200-1600°C)
```

**Why direct to Stage 7?** Ferrous melts at 1538°C. Feeding at Stage 1 (150°C) would:
- Dilute thermal cascade (cold steel absorbs heat)
- Oxidize in drum atmosphere (Fe + H2O → Fe3O4 + H2)
- Contaminate Al/Cu slugs (Fe particles in non-ferrous melt)

**Stage 7 buffer sizing:** 1 m³ = 7.8 ton steel (ρ=7850 kg/m³). At 40% ferrous in 4,000 ton/yr = 1,600 ton/yr ferrous = 200 ton/batch × 8 batches. Buffer holds 1 batch → continuous operation.

### 11.4 Control System Integration — All-Optical

**Signal mapping (PMMA POF, WDM multiplexed):**

| Signal | Source | Destination | Wavelength | Protocol |
|--------|--------|-------------|------------|----------|
| Moisture % | Capacitive sensor | Drum PLC | 660 nm | Analog intensity |
| Particle size (P80) | Sieve analyzer | Drum PLC | 780 nm | Digital (Manchester) |
| Vibration (FBG) | Rotor FBGs | Health monitor | 850 nm | FBG interrogator |
| Temperature (FBG) | Chamber FBGs | Drum PLC | 1310 nm | FBG interrogator |
| E-stop status | Safety PLC | All systems | 1550 nm | Safety bus (SIL-3) |
| Gate position | Feed gate encoder | Drum PLC | 660 nm | Quadrature |
| Ferrous flow | Magnet belt FBG | Stage 7 PLC | 780 nm | Digital |
| N2 pressure | Chamber transducers | Drum PLC | 1310 nm | Analog |
| X-ray battery detect | X-ray system | Eject controller | 1550 nm | Safety bus |

**Zero copper conductors** — complete dielectric isolation from drum control system. The only "wire" crossing the boundary is light in PMMA fiber.

