ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x095bd431d1b01bd6   0   0   0 255
Solid    "Gray 90%"                 0x095bd431d1b01bd8  25  25  25 255
Solid    "Gray 80%"                 0x095bd431d1b01bda  51  51  51 255
Solid    "Gray 70%"                 0x095bd431d1b01bdc  76  76  76 255
Solid    "Gray 60%"                 0x095bd431d1b01bde 102 102 102 255
Solid    "Gray 50%"                 0x095bd431d1b01be0 127 127 127 255
Solid    "Gray 40%"                 0x095bd431d1b01be2 153 153 153 255
Solid    "Gray 30%"                 0x095bd431d1b01be4 179 179 179 255
Solid    "Gray 20%"                 0x095bd431d1b01be6 204 204 204 255
Solid    "Gray 10%"                 0x095bd431d1b01be8 230 230 230 255
Solid    White                      0x095bd431d1b01bea 255 255 255 255
Solid    "Rough Blue"               0x095bd431d1b01bec  55 178 255 255
Solid    "Revision Red"             0x095bd431d1b01bee 255  44   0 255
Solid    Yellow                     0x095bd431d1b01bf0 255 255   0 255
