ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x095bc191b3d011d5   0   0   0 255
Solid    "Gray 90%"                 0x095bc191b3d011d7  25  25  25 255
Solid    "Gray 80%"                 0x095bc191b3d011d9  51  51  51 255
Solid    "Gray 70%"                 0x095bc191b3d011db  76  76  76 255
Solid    "Gray 60%"                 0x095bc191b3d011dd 102 102 102 255
Solid    "Gray 50%"                 0x095bc191b3d011df 127 127 127 255
Solid    "Gray 40%"                 0x095bc191b3d011e1 153 153 153 255
Solid    "Gray 30%"                 0x095bc191b3d011e3 179 179 179 255
Solid    "Gray 20%"                 0x095bc191b3d011e5 204 204 204 255
Solid    "Gray 10%"                 0x095bc191b3d011e7 230 230 230 255
Solid    White                      0x095bc191b3d011e9 255 255 255 255
Solid    "Rough Blue"               0x095bc191b3d011eb  55 178 255 255
Solid    "Revision Red"             0x095bc191b3d011ed 255  44   0 255
Solid    Yellow                     0x095bc191b3d011ef 255 255   0 255
